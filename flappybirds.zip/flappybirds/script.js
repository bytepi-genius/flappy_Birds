const bird = document.getElementById("bird");
const gameContainer = document.querySelector(".game-container");
const scoreElement = document.getElementById("score");
const restartBtn = document.getElementById("restart-btn");

let birdY = 250;
let gravity = 1.5;
let jumpStrength = -25;
let score = 0;
let gameSpeed = 2;
let gameInterval;
let poleInterval;
let isGameOver = false;

// Bird movement
document.addEventListener("keydown", (event) => {
  if (isGameOver) return; // Stop movement if game is over

  if (event.code === "Space" || event.code === "ArrowUp") {
    birdY += jumpStrength * 2; // Jump up on spacebar or up arrow key
  } else if (event.code === "ArrowDown") {
    birdY -= jumpStrength; // Move down on down arrow key
  }
});

// Update bird position
function updateBird() {
  if (isGameOver) return; // Stop updating if game is over

  birdY += gravity;
  bird.style.top = birdY + "px";

  // Check for collisions with top or bottom
  if (birdY <= 0 || birdY >= gameContainer.clientHeight - 40) {
    endGame();
  }
}

// Generate poles
function createPole() {
  if (isGameOver) return; // Stop generating poles if game is over

  const poleGap = 150;
  const poleHeight = Math.random() * (gameContainer.clientHeight - poleGap - 100) + 50;

  // Top Pole
  const topPole = document.createElement("img");
  topPole.src = "rectangle (1).png"; // Path to top pole image
  topPole.classList.add("pole");
  topPole.style.height = poleHeight + "px";
  topPole.style.top = "0";
  topPole.style.left = gameContainer.clientWidth + "px";

  // Bottom Pole
  const bottomPole = document.createElement("img");
  bottomPole.src = "rectangle.png"; // Path to bottom pole image
  bottomPole.classList.add("pole");
  bottomPole.style.height = gameContainer.clientHeight - poleHeight - poleGap + "px";
  bottomPole.style.bottom = "0";
  bottomPole.style.left = gameContainer.clientWidth + "px";

  gameContainer.appendChild(topPole);
  gameContainer.appendChild(bottomPole);

  // Move poles
  let polePosition = gameContainer.clientWidth;
  const poleMoveInterval = setInterval(() => {
    if (isGameOver) {
      clearInterval(poleMoveInterval);
      return;
    }

    polePosition -= gameSpeed;
    topPole.style.left = polePosition + "px";
    bottomPole.style.left = polePosition + "px";

    // Check if bird passes the poles
    if (polePosition === 50) {
      score++;
      scoreElement.textContent = `Score: ${score}`;
    }

    // Remove poles when they go off-screen
    if (polePosition < -60) {
      clearInterval(poleMoveInterval);
      gameContainer.removeChild(topPole);
      gameContainer.removeChild(bottomPole);
    }

    // Check for collisions
    if (
      (polePosition < 90 && polePosition > 50) &&
      (birdY < poleHeight || birdY > poleHeight + poleGap)
    ) {
      endGame();
    }
  }, 20);
}

// End the game
function endGame() {
  isGameOver = true;
  clearInterval(gameInterval);
  clearInterval(poleInterval);

  // Show game over message
  const gameOverMessage = document.createElement("div");
  gameOverMessage.textContent = `Game Over! Your score is ${score}. Restarting...`;
  gameOverMessage.style.position = "absolute";
  gameOverMessage.style.top = "50%";
  gameOverMessage.style.left = "50%";
  gameOverMessage.style.transform = "translate(-50%, -50%)";
  gameOverMessage.style.color = "white";
  gameOverMessage.style.fontSize = "24px";
  gameOverMessage.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
  gameOverMessage.style.padding = "10px";
  gameOverMessage.style.borderRadius = "5px";
  gameContainer.appendChild(gameOverMessage);

  // Restart the game after 3 seconds
  setTimeout(() => {
    window.location.reload();
  }, 3000);
}

// Start the game
function startGame() {
  gameInterval = setInterval(updateBird, 20);
  poleInterval = setInterval(createPole, 2000);
}

// Restart the game
restartBtn.addEventListener("click", () => {
  window.location.reload();
});

startGame();